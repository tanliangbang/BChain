export const lang = {
  header: {
    hq: '行情',
    jy: '交易',
    dr: '登入',
    zc: '注册'
  }
}
