export const lang = {
  header: {
    hq: 'OTC',
    jy: 'EXCHANGE',
    dr: 'Log In',
    zc: 'Sign Up'
  }
}
